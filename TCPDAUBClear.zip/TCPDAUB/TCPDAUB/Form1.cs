﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;//匯入網路通訊協定相關函數
using System.Net.Sockets;//匯入網路插座功能函數
using System.Threading;//匯入多執行緒功能函數
using static System.Net.WebRequestMethods;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using System.Security.Cryptography;

namespace TCPDAUB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //公用變數
        Socket T;//通訊物件
        Thread Th;//網路監聽執行緒
        string User;//使用者
        Pen pen;
        int penPoint;
        Color penColor;
        Bitmap bmp;
        Graphics g;
        string send;
        //監聽 Server 訊息 (Listening to the Server)

        private void Listen()
        {
            EndPoint ServerEP = (EndPoint)T.RemoteEndPoint; //Server 的 EndPoint
            byte[] B = new byte[1023]; //接收用的 Byte 陣列
            int inLen = 0; //接收的位元組數目
            string Msg; //接收到的完整訊息
            string St; //命令碼
            string Str; //訊息內容(不含命令碼)
            int penpoint;
            Color Color;  
            while (true)//無限次監聽迴圈
            {
                try
                {
                    inLen = T.ReceiveFrom(B, ref ServerEP);//收聽資訊並取得位元組數
                }
                catch (Exception)//產生錯誤時
                {
                    T.Close();//關閉通訊器
                    ListBox1.Items.Clear();//清除線上名單
                    MessageBox.Show("伺服器斷線了！");//顯示斷線
                    Button1.Enabled = true;//連線按鍵恢復可用
                    Th.Abort();//刪除執行緒
                }
                Msg = Encoding.Default.GetString(B, 0, inLen); //解讀完整訊息
                St = Msg.Substring(0, 1); //取出命令碼 (第一個字)
                Str = Msg.Substring(1); //取出命令碼之後的訊息   
                switch (St)//依命令碼執行功能
                {
                    case "L"://接收線上名單
                        ListBox1.Items.Clear(); //清除名單
                        string[] M = Str.Split(','); //拆解名單成陣列
                        for (int i = 0; i < M.Length; i++)
                        {
                            ListBox1.Items.Add(M[i]); //逐一加入名單
                        }
                        break;
                    case "D"://接收畫圖
                        string[] E = Str.Split('-'); //拆解名單成陣列 E[0]顏色 E[1]筆畫粗細E[2]座標
                        string[] Z = E[2].Split('/');//切割顏色與座標資訊
                        Point[] R = new Point[Z.Length];//宣告座標點陣列 Z.Length=有n組XY座標
                        Color = Color.FromName(E[0].ToString());//設定顏色
                       
                        penpoint = int.Parse(E[1]);//設定筆畫                       
                        pen = new Pen(Color, penpoint);//設定畫筆

                        int ex=0,ey=0;
                        for (int i = 0; i < Z.Length-1; i++)
                        {
                            string[] K = Z[i].Split(',');//切割X與Y座標 K[0] X1 K[1] Y1 K[2] X2 K[3] Y2

                            R[i].X = int.Parse(K[0]);//定義第i點X座標
                            R[i].Y = int.Parse(K[1]);//定義第i點Y座標

                            string[] KK = Z[i + 1].Split(',');

                            ex = int.Parse(KK[0]);
                            ey = int.Parse(KK[1]);
                            g.DrawLine(pen, R[i].X, R[i].Y, ex, ey);  
                        }
                        g = Graphics.FromImage(bmp);
                        pictureBox1.Image = bmp;
                        break;
                    case "C":
                        clear();
                        break;
                }
            }
        }
        //傳送訊息給 Server (Send Message to the Server)
        private void Send(string Str)
        {
            byte[] B = Encoding.Default.GetBytes(Str); //翻譯文字為Byte陣列
            T.Send(B, 0, B.Length, SocketFlags.None); //使用連線物件傳送資料
        }
        //登入伺服器
        private void Button1_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false; //忽略跨執行緒錯誤
            User = TextBox3.Text;//使用者名稱
            string IP = TextBox1.Text;//伺服器IP
            int Port = int.Parse(TextBox2.Text);//伺服器Port
            //建立通訊物件，參數代表可以雙向通訊的TCP連線
            try
            {
                IPEndPoint EP = new IPEndPoint(IPAddress.Parse(IP), Port);//伺服器的連線端點資訊
                T = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                T.Connect(EP); //連上伺服器的端點EP(類似撥號給電話總機)
                Th = new Thread(Listen); //建立監聽執行緒
                Th.IsBackground = true; //設定為背景執行緒
                Th.Start(); //開始監聽
                TextBox4.Text = "已連線伺服器！" + "\r\n";
                Send("0" + User);  //連線後隨即傳送自己的名稱給伺服器
            }
            catch (Exception)
            {
                TextBox4.Text = "無法連上伺服器！" + "\r\n"; //連線失敗時顯示訊息
                return;
            }
            Button1.Enabled = false; //讓連線按鍵失效，避免重複連線
            
        }
        
        //視窗關閉，代表離線
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Button1.Enabled == false)
            {
                Send("9" + User); //傳送自己的離線訊息給伺服器
                T.Close(); //關閉網路通訊器
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Graphics graphics = pictureBox1.CreateGraphics();
            pen = new Pen(Color.Black, 5);
            bmp = new Bitmap(this.Width, this.Height);
            g = Graphics.FromImage(bmp);
            penPoint = 3;
            //pictureBox1.Size = new Size(this.Width, this.Height);
            // pictureBox1.Location = new Point(0, 25);
            penColor = Color.Black;
            g.Clear(Color.White);
            pictureBox1.Image = bmp;
            pictureBox1.Refresh();
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
               //建立線段物件
                g = Graphics.FromImage(bmp);
                    g.DrawLine(pen, oldx, oldy, e.X, e.Y);
                    pictureBox1.Image = bmp; 
                    oldx = e.X;
                    oldy = e.Y;
                    textBox5.Text += oldx + "," + oldy;
                 send+="/"+oldx+","+oldy;
            }
        }
        int oldx, oldy;

        private void button4_Click(object sender, EventArgs e)
        {
            clear();
            send ="C";
            Send(send);
        }
        private void clear()
        {
            pictureBox1.Image = null;
            g.Clear(Color.White);
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
           
            send = "D"+ color + "-" + penPoint + "-" +send;//紀錄開始繪圖座標
            Send(send);
            //MessageBox.Show(send);
            //string[] E = send.Split('-'); //拆解名單成陣列     
            //    MessageBox.Show( E[0],"E[0]");
            //    MessageBox.Show(E[1], "E[1]");
            //    MessageBox.Show(E[2], "E[2]");

            //string[] Z = E[2].Split('/');//切割座標Z[0]X1,Y1 Z[2]X2,Y2
            //for (int i = 0; i < Z.Length; i++)
            //{
            //    MessageBox.Show(Z[i], "Z[" + Z[i] +"]");
            //}
          
        }
        string color;
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (radioButton1.Checked) { penColor = Color.Red;color = "Red"; }//紅筆
            if (radioButton2.Checked) { penColor = Color.Blue;color = "Blue"; }//亮綠色筆
            if (radioButton3.Checked) { penColor = Color.Lime; color = "Lime"; }//藍筆
            if (radioButton4.Checked) { penColor = Color.Black; color = "Black"; }//黑筆
            if (radioButton5.Checked) { penColor = Color.White; color = "White"; }//
            penPoint = trackBar1.Value;            
            pen = new Pen(penColor, penPoint);
            oldx = e.X;//起點
            oldy = e.Y;//起點
           
            send = oldx + "," + oldy;//起點座標紀錄
        }
    }
}
